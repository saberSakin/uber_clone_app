"use strict";
(() => {
var exports = {};
exports.id = 864;
exports.ids = [864];
exports.modules = {

/***/ 689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 191:
/***/ ((module) => {

module.exports = require("tailwind-styled-components");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [822], () => (__webpack_exec__(822)));
module.exports = __webpack_exports__;

})();