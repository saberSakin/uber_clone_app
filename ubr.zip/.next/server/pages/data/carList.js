"use strict";
(() => {
var exports = {};
exports.id = 815;
exports.ids = [815];
exports.modules = {

/***/ 307:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "carList": () => (/* binding */ carList)
/* harmony export */ });
const carList = [
    {
        imgUrl: "https://i.ibb.co/cyvcpfF/uberx.png",
        service: "UberX",
        multiplier: 1
    },
    {
        imgUrl: "https://i.ibb.co/YDYMKny/uberxl.png",
        service: "UberXL",
        multiplier: 1.5
    },
    {
        imgUrl: "https://i.ibb.co/Xx4G91m/uberblack.png",
        service: "Black",
        multiplier: 2
    },
    {
        imgUrl: "https://i.ibb.co/cyvcpfF/uberx.png",
        service: "Comfort",
        multiplier: 1.2
    },
    {
        imgUrl: "https://i.ibb.co/1nStPWT/uberblacksuv.png",
        service: "Black SUV",
        multiplier: 2.8
    }
];


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(307));
module.exports = __webpack_exports__;

})();