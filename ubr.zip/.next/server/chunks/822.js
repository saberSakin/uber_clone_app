"use strict";
exports.id = 822;
exports.ids = [822,815];
exports.modules = {

/***/ 822:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var tailwind_styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(191);
/* harmony import */ var tailwind_styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(tailwind_styled_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _data_carList__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(307);




const RideSelector = ({ pickupCoordinates , dropoffCoordinates  })=>{
    const [rideDuration, setRideDuration] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(0);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        const fetchData = async ()=>{
            try {
                const response = await fetch(`https://api.mapbox.com/directions/v5/mapbox/driving/${pickupCoordinates[0]},${pickupCoordinates[1]};${dropoffCoordinates[0]},${dropoffCoordinates[1]}?access_token=pk.eyJ1Ijoic2FiZXJ0b290aDkxNTMiLCJhIjoiY2xvZDlqYncyMDVhdDJxcDl1MjExZ2xiZCJ9.UcJ5o-jece5CN3ud748fJg`);
                if (!response.ok) {
                    throw new Error("Network response was not ok");
                }
                const data = await response.json();
                if (data.routes && data.routes.length > 0) {
                    setRideDuration(data.routes[0].duration / 100);
                } else {
                    console.error("No routes found in the API response.");
                }
            } catch (error) {
                console.error("Error fetching or processing data:", error);
            }
        };
        fetchData();
    }, [
        pickupCoordinates,
        dropoffCoordinates
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(Wrapper, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Title, {
                children: "Choose a ride or swipe up for more"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(CarList, {
                children: _data_carList__WEBPACK_IMPORTED_MODULE_3__.carList.map((car, index)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(Car, {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(CarImage, {
                                src: car.imgUrl
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(CarDetails, {
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Service, {
                                        children: car.service
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Time, {
                                        children: "5 min away"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Price, {
                                children: "$" + (rideDuration * car.multiplier).toFixed(2)
                            })
                        ]
                    }, index))
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (RideSelector);
const CarDetails = (tailwind_styled_components__WEBPACK_IMPORTED_MODULE_2___default().div)`
flex-1`;
const Service = (tailwind_styled_components__WEBPACK_IMPORTED_MODULE_2___default().div)`font-medium`;
const Time = (tailwind_styled_components__WEBPACK_IMPORTED_MODULE_2___default().div)`text xs text-blue-500`;
const Price = (tailwind_styled_components__WEBPACK_IMPORTED_MODULE_2___default().div)`text-sm`;
const CarImage = (tailwind_styled_components__WEBPACK_IMPORTED_MODULE_2___default().img)`
h-14 mr-2`;
const Car = (tailwind_styled_components__WEBPACK_IMPORTED_MODULE_2___default().div)`
flex p-4 item-center`;
const Title = (tailwind_styled_components__WEBPACK_IMPORTED_MODULE_2___default().div)`
text-gray-500 text-center text-xs py-2 border-b`;
const CarList = (tailwind_styled_components__WEBPACK_IMPORTED_MODULE_2___default().div)`
overflow-y-scroll`;
const Wrapper = (tailwind_styled_components__WEBPACK_IMPORTED_MODULE_2___default().div)`
flex-1 overflow-y-scroll flex flex-col`;


/***/ }),

/***/ 307:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "carList": () => (/* binding */ carList)
/* harmony export */ });
const carList = [
    {
        imgUrl: "https://i.ibb.co/cyvcpfF/uberx.png",
        service: "UberX",
        multiplier: 1
    },
    {
        imgUrl: "https://i.ibb.co/YDYMKny/uberxl.png",
        service: "UberXL",
        multiplier: 1.5
    },
    {
        imgUrl: "https://i.ibb.co/Xx4G91m/uberblack.png",
        service: "Black",
        multiplier: 2
    },
    {
        imgUrl: "https://i.ibb.co/cyvcpfF/uberx.png",
        service: "Comfort",
        multiplier: 1.2
    },
    {
        imgUrl: "https://i.ibb.co/1nStPWT/uberblacksuv.png",
        service: "Black SUV",
        multiplier: 2.8
    }
];


/***/ })

};
;